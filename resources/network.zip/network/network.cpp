#include <bits/stdc++.h>
using namespace std;
struct sb
{
    string ad;
    int n;
}server[1001];
int n, cc, sc, ii = -1;
double a,b,c,d,e;
bool v(string s)
{
    int i=0;
    string tmp = s;
    for( int i = 1; i <= 3; i ++)
        if( tmp.find(".") != string::npos)
            tmp.erase(tmp.find("."),1);
        else return false;
    if( tmp.find(".") != string::npos) return false;
    if(tmp.find(":") != string::npos) s.erase(s.find(":"),1);
    else return false;
    for(int j=0; i < s.size(); i ++, j++)
    {
        if( s[i] <= '9' && s[i] >= '0')
        {
            a += pow(10,j) + int(s[i]-'0');
        }
        else break;
    }
    i +=2;
    for(int j=0; i < s.size(); i ++, j++)
    {
        if( s[i] <= '9' && s[i] >= '0')
        {
            b += pow(10,j) + int(s[i]-'0');
        }
        else break;
    }
    i+=2;
    for(int j=0; i < s.size(); i ++, j++)
    {
        if( s[i] <= '9' && s[i] >= '0')
        {
            c += pow(10,j) + int(s[i]-'0');
        }
        else break;
    }
    i+=2;
    for( int j=0; i < s.size(); i ++, j++)
    {
        if( s[i] <= '9' && s[i] >= '0')
        {
            d += pow(10,j) + int(s[i]-'0');
        }
        else break;
    }
    i+=2;
    for( int j=0; i < s.size(); i ++, j++)
    {
        if( s[i] <= '9' && s[i] >= '0')
        {
            e += pow(10,j) + int(s[i]-'0');
        }
        else break;
    }
    if( 0 <= a && a <= 255 && 0 <= b && b <= 255 && 0 <= c && c <= 255 && 0 <= d && d <= 255 && 0 <= e && e <= 65535)
        return true;
    else
        return false;
}
int main()
{
    freopen("network.in", "r", stdin);
    freopen("network.out", "w", stdout);
    string op, ad;
    string client[1001];
    bool connect = false;
    cin >> n;
    for(int i = 1; i <= n; i ++)
    {
        cin >> op >> ad;
        if(v(ad) == false)
        {
            cout << "ERR" << endl;
        }
        else
        {
            if(op[0] == 'S')
            {
                for( int i = 0; i <= sc; i ++)
                {
                    if(server[i].ad == ad)
                    {
                        cout << "FAIL" << endl;
                    }
                }
                sc ++;
                server[sc].ad = ad;
                server[sc].n = i;
                cout << "OK" << endl;
            }
            else if(op[0] == 'C')
            {
                for( int i = 1; i <= sc; i ++)
                {
                    if(ad == server[i].ad)
                    {
                        cout << server[i].n << endl;
                        connect = true;
                        break;
                    }
                }
                if(!connect)
                {
                    cout << "FAIL" << endl;
                    connect = false;
                }
            }
        }
    }

    return 0;
}
