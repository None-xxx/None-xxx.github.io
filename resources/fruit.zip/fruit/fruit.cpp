#include <bits/stdc++.h>
using namespace std;
struct f
{
    int t;
    int n;
};
int n;
f a[20005];
bool aa()
{
    for( int i = 1; i <= n; i ++)
    {
        if( a[i].t > 0) return false;
    }
    return true;
}
int main()
{
    freopen("fruit.in", "r", stdin);
    freopen("fruit.out", "w", stdout);
    for( int i = 0; i <= 20004; i ++)
    {
        a[i].t = -1;
    }
    a[0].t = -1;
    scanf("%d", &n);
    for( int i = 1; i <= n; i ++)
    {
        scanf("%d", &a[i].t);
        a[i].n = i;
    }
    printf("%d", a[1].n);
    a[1].t = -1-a[1].t;
    while(1)
    {
        for( int i = 1; i <= n; i ++)
        {
            if(a[i-1].t != -1-a[i].t && a[i-1].t != a[i].t)
            {
                printf("%d ", a[i].n);
                a[i].t = -1-a[i].t;
            }
        }
        printf("\n");
        if(aa()) break;
    }
    return 0;
}
