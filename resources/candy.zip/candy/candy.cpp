#include <bits/stdc++.h>
using namespace std;
int n, l, r, maxn = -1;
int main()
{
    freopen("candy.in", "r", stdin);
    freopen("candy.out", "w", stdout);
    cin >> n >> l >> r;
    for(int i = l; i <= r; i ++)
    {
        if(i % n > maxn)
        {
            maxn = i % n;
        }
    }
    cout << maxn;
    return 0;
}
