#include <bits/stdc++.h>
using namespace std;
struct number
{
    int n;
    int i;
};
number a[8001], b[8001];
int n, q, cmd, x, y, num;
bool cmp( number x, number y)
{
    return x.n < y.n;
}
void s()
{
    for (int i = 1; i <= n; i++)
    {
        for (int j = i; j>=2; j--)
        {
            if(a[j].n < a[j-1].n)
            {
                swap(a[j-1], a[j]);
            }
        }
    }
}
void initb()
{
    for( int i = 1; i <= n; i ++ )
    {
        b[i].n = a[i].n;
        b[i].i = a[i].i;
    }
}
void inita()
{
    for( int i = 1; i <= n; i ++ )
    {
        a[i].n = b[i].n;
        a[i].i = b[i].i;
    }
}
int main()
{
    freopen("sort.in", "r", stdin);
    freopen("sort.out", "w", stdout);
    cin >> n >> q;
    for( int i = 1; i <= n; i ++ )
    {
        cin >> a[i].n;
        a[i].i = i;
    }
    for( int i = 1; i <= q; i ++ )
    {
        cin >> cmd;
        if(cmd == 1)
        {
            cin >> x >> y;
            a[x].n = y;
        }
        else if(cmd == 2)
        {
            cin >> num;
            initb();
            s();
            for( int i = 1; i <= n; i ++ )
            {
                if( a[i].i == num)
                {
                    cout << i << endl;
                    break;
                }
            }
            inita();
        }
    }
    return 0;
}
